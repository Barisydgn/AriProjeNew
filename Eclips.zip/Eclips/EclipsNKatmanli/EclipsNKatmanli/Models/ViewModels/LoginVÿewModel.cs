﻿namespace EclipsNKatmanli.Models.ViewModels
{
    public class LoginVİewModel
    {
        public string KullaniciAd { get; set; }
        public string Sifre { get; set; }
    }
}
