﻿using AutoMapper;
using Core.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Model.Entities;
using System.Collections.Generic;

namespace EclipsNKatmanli.Controllers
{
    //MODAL BOOTSTRAP EKLE ÖNEMLİ

    public class MusteriController : Controller
    {
        private readonly ICoreService<Musteri> _coreService;
      

        public MusteriController(ICoreService<Musteri> coreService)
        {
            _coreService = coreService;
           
        }

        public IActionResult Listeleme()
        {
          var musteri=  _coreService.GetAll();          
            ViewBag.MusteriListeleme= musteri;
            return View();
        }

        //[HttpPost]
        //public IActionResult Ekleme(MusteriViewModel musteri)
        //{
        //    var map = _mapper.Map<Personel>(musteri);
        //    _coreService.Add(map);
        //    return View();
        //}

        [HttpPost]
        public IActionResult Ekleme(Musteri p)
        {
            if (p.MusteriAd!=null && p.MusteriSoyad!=null && p.Yorum!=null)
            {
                _coreService.Add(p);
               return View("Listeleme");
            }
            else
            {              
                return View("Listeleme");
            }
        }
        
    }
}
