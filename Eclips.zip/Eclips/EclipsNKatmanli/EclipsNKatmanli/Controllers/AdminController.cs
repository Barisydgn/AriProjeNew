﻿using Core.Service;
using EclipsNKatmanli.Models.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Model.Entities;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace EclipsNKatmanli.Controllers
{
    [AllowAnonymous]
    public class AdminController : Controller
    {
        private readonly ICoreService<Admin> _adminDb;

        public AdminController(ICoreService<Admin> adminDb)
        {
            _adminDb = adminDb;
        }

        [HttpGet]
        public IActionResult GirisPaneli()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GirisPaneli(LoginVİewModel lvm)
        {
           
                var result = _adminDb.GetRecord(x => x.KullaniciAd==lvm.KullaniciAd && x.Sifre==lvm.Sifre);
                if (result != null)
                {
                   
                    var claims = new List<Claim>()
                    {
                       new Claim("ID",result.ID.ToString()),
                       new Claim("KullaniciAd", result.KullaniciAd),
                       new Claim("Sifre", result.Sifre)
                    };
                    
                    var user = new ClaimsIdentity(claims, "GirisPaneli");

                   
                    ClaimsPrincipal principal = new ClaimsPrincipal(user);

                   
                    await HttpContext.SignInAsync(principal); 

                    return RedirectToAction("Index", "Admin", new { area = "Admin" });
                }
                return View();
          
            
        }


        public async Task<IActionResult> CikisPaneli()
        {
             await HttpContext.SignOutAsync();
            return View("Anasayfa","Home");
        }

    }
}
