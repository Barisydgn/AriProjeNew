﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EclipsNKatmanli.Controllers
{
  
    public class EclipsController : Controller
    {
        public IActionResult Hakkında()
        {
            return View();
        }

        public IActionResult İletisim()
        {
            return View();
        }
    }
}
