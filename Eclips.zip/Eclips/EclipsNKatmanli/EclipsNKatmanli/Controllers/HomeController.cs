﻿using Microsoft.AspNetCore.Mvc;

namespace EclipsNKatmanli.Controllers
{
	public class HomeController : Controller
	{
		public IActionResult Index()
		{
			return View();
		}

		public IActionResult Anasayfa()
		{
			return View();
		}
	}
}
