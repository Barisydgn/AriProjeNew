﻿using AutoMapper;
using Core.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Model.Entities;
using System.Collections.Generic;

namespace EclipsNKatmanli.Controllers
{
   
    public class EkipController : Controller
    {
        private readonly ICoreService<Personel> _person;

       
        public EkipController(ICoreService<Personel> person)
        {
            _person = person;
          
        }

        public IActionResult Listeleme()
        {       
          return View(_person.GetAll());
        }
    }
}
