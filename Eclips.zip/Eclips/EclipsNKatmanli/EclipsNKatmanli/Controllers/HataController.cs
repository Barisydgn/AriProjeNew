﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EclipsNKatmanli.Controllers
{
    public class HataController : Controller
    {
      
        public IActionResult HataSayfası(int code)
        {
            return View();
        }
    }
}
