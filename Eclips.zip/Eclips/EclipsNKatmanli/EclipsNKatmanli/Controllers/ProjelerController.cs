﻿using Core.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;
using Model.Entities;

namespace EclipsNKatmanli.Controllers
{
   
    

    public class ProjelerController : Controller
    {
        private readonly ICoreService<Projeler> _pro;
        private readonly IFileProvider _fileprovider;

        public ProjelerController(ICoreService<Projeler> pro, IFileProvider fileprovider)
        {
            _pro = pro;
            _fileprovider = fileprovider;
        }

        //BURAYA IFİLEPROVİDER EKLE FOTO İÇİN
        public IActionResult Listeleme()
        {
            return View(_pro.GetAll());
        }

        public IActionResult Detay(int id)
        {
            return View(_pro.GetByID(id));
        }
    }
}
