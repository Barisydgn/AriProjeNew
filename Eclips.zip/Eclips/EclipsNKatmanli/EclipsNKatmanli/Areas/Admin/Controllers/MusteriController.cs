﻿using Core.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Model.Entities;

namespace EclipsNKatmanli.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]
    public class MusteriController : Controller
    {
        private readonly ICoreService<Musteri> _mus;

        public MusteriController(ICoreService<Musteri> mus)
        {
            _mus = mus;
        }

       
        public IActionResult Listeleme()
        {
            return View(_mus.GetAll());
        }

        public IActionResult Silme(int id)
        {
            return _mus.Delete(id) ? View("Listeleme", _mus.GetAll()) : View();
        }
    }
}
