﻿using AutoMapper;
using Core.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Model.Entities;

namespace EclipsNKatmanli.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]
    public class EkipController : Controller
    {
        private readonly ICoreService<Personel> _per;
    

        public EkipController(ICoreService<Personel> per)
        {
            _per = per;
        }
       
        public IActionResult Listeleme()
        {
            return View(_per.GetAll());
        }
      
        public IActionResult Silme(int id)
        {
            return  _per.Delete(id) ? View("Listeleme", _per.GetAll()) : View();
        }

        public IActionResult Guncelleme(int id)
        {
            return View(_per.GetByID(id));
        }

        [HttpPost]
        public IActionResult Guncelleme(Personel p)
        {
            if(p.Ad !=null && p.Soyad !=null && p.Ünvan !=null && p.Yas != null)
            {
                return _per.Update(p) ? View("Listeleme", _per.GetAll()) : View();
            }
            ViewBag.Error = "Güncelleme Yapılırken Hata Oluştu";
            return View();
        }

        public IActionResult Ekleme()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Ekleme(Personel p)
        {
            if (p.Ad != null && p.Soyad != null && p.Ünvan != null && p.Yas != null)
            {
                return _per.Add(p) ? View("Listeleme", _per.GetAll()) : View();
            }
            ViewBag.EklemeError = "Personel Eklerken Hata Oluştur";
            return View();

        }
    }
}
