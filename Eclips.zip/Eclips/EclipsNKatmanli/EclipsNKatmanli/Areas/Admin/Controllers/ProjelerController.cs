﻿using Core.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;
using Model.Entities;
using System;
using System.IO;
using System.Linq;

namespace EclipsNKatmanli.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize]
   
    public class ProjelerController : Controller
    {
        private readonly ICoreService<Projeler> _pro;
        private readonly IFileProvider _fileProvider;

        public ProjelerController(ICoreService<Projeler> pro, IFileProvider fileProvider)
		{
			_pro = pro;
            _fileProvider = fileProvider;
        }
        
		public IActionResult Listeleme()
        {
            return View(_pro.GetAll());
        }

        public IActionResult Silme(int id)
        {
            return _pro.Delete(id) ? View("Listeleme", _pro.GetAll()) : View();
        }

        public IActionResult Ekleme()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Ekleme(Projeler p)
        {
           
				var root = _fileProvider.GetDirectoryContents("wwwroot");
				var images = root.First(x => x.Name == "images");
				var randomİmages = Guid.NewGuid() + Path.GetExtension(p.Image.FileName);
				var path = Path.Combine(images.PhysicalPath, randomİmages);
				using var stream = new FileStream(path, FileMode.Create);
				p.Image.CopyTo(stream);
				//if (p.Image==null)
				//{
				//    //p.Image=
				//}
				p.ImagePath = randomİmages;

            if (p.ProjeAd != null && p.Tarih != null&& p.ProjeSahibi!=null)
            {
                return _pro.Add(p) ? View("Listeleme", _pro.GetAll()) : View();
            }
            ViewBag.EklemeError = "Projeyi Eklerken Hata Oluştu";
            return View();


        }
       
        public IActionResult Guncelleme(int id)
        {
            return View(_pro.GetByID(id));
        }
        [HttpPost]
        public IActionResult Guncelleme(Projeler p)
        {
            var root = _fileProvider.GetDirectoryContents("wwwroot");
            var images = root.First(x => x.Name == "images");
            var randomİmages = Guid.NewGuid() + Path.GetExtension(p.Image.FileName);
            var path = Path.Combine(images.PhysicalPath, randomİmages);
            using var stream = new FileStream(path, FileMode.Create);
            p.Image.CopyTo(stream);
            p.ImagePath = randomİmages;


            if (p.ProjeAd != null && p.Tarih != null && p.ProjeSahibi != null)
            {
                return _pro.Update(p) ? View("Listeleme", _pro.GetAll()) : View();
            }
            ViewBag.GuncellemeError = "Projeyi Güncellerken Hata Oluştu";
            return View();
        }
    }
}
